import bpy


class MixamoInPlacerForward(bpy.types.Operator):
    """Remove forward movement only"""
    bl_idname = "object.mixamo_in_placer_forward"
    bl_label = "Forward Movement"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        
        # Check selected object(s)
        
        if (len(bpy.context.selected_objects) <1 ):
            self.report({'ERROR'}, "Error: no object is selected. Please select the Armature object.")
            return{ 'CANCELLED'}
        
        if (len(bpy.context.selected_objects) >1 ):
            self.report({'ERROR'}, "Error: more than one object is selected. Please select the Armature object.")
            return{ 'CANCELLED'}
        
        if bpy.context.object.type != 'ARMATURE':
            self.report({'ERROR'}, "Error: %s is not an Armature." % bpy.context.object.name)
            return{ 'CANCELLED'}

        bpy.ops.object.mode_set(mode="OBJECT")
        
        if bpy.context.object.type == 'ARMATURE':
            self.report({'INFO'}, "Forward movement is removed")
            
        #get the firts and the last frame of the animation
        first_frame = bpy.context.selected_objects[0].animation_data.action.frame_range[0]
        first_frame = int(first_frame)
        frame_range = bpy.context.selected_objects[0].animation_data.action.frame_range[1]
        frame_range = int(frame_range)
        frame_range +=1

        if ((bpy.context.selected_objects[0].name) == "root"):

            for i in range(first_frame, frame_range):
                
                #set current frame
                bpy.context.scene.frame_current = i
                
                #set Y location 0 for every keyframe
                
                bpy.context.selected_objects[0].location[1] = 0
                bpy.context.selected_objects[0].keyframe_insert(data_path="location", frame=i, index=1)
                bpy.context.selected_objects[0].location[1] = 0
                
                #insert keyframe to make it permenant
                bpy.ops.anim.keyframe_insert_menu(type='Location')
            
            
            #go back to the first frame    
            bpy.context.scene.frame_current = first_frame
        
            return {'FINISHED'}

        else:
            try:
            
                for i in range(first_frame, frame_range):
                    
                    #set current frame@
                    bpy.context.scene.frame_current = i
                    
                    #set Z location 0 for every keyframe
                    
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].location[2] = 0
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].keyframe_insert(data_path="location", frame=i, index=2)
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].location[2] = 0
                    
                    #insert keyframe to make it permenant
                    bpy.ops.anim.keyframe_insert_menu(type='Location')
                
                
                #go back to the first frame    
                bpy.context.scene.frame_current = first_frame
            
                return {'FINISHED'}
            except:
                for i in range(first_frame, frame_range):
                    
                    #set current frame@
                    bpy.context.scene.frame_current = i
                    
                    #set Z location 0 for every keyframe
                    
                    bpy.context.selected_objects[0].pose.bones["Hips"].location[2] = 0
                    bpy.context.selected_objects[0].pose.bones["Hips"].keyframe_insert(data_path="location", frame=i, index=2)
                    bpy.context.selected_objects[0].pose.bones["Hips"].location[2] = 0
                    
                    #insert keyframe to make it permenant
                    bpy.ops.anim.keyframe_insert_menu(type='Location')
                
                
                #go back to the first frame    
                bpy.context.scene.frame_current = first_frame
                return {'FINISHED'}


class MixamoInPlacerForwardandLateral(bpy.types.Operator):
    """Remove forward and lateral movement"""
    bl_idname = "object.mixamo_in_placer_forward_and_lateral"
    bl_label = "Make it in place!"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        
        # Check selected object(s)
        
        if (len(bpy.context.selected_objects) <1 ):
            self.report({'ERROR'}, "Error: no object is selected. Please select the Armature object.")
            return{ 'CANCELLED'}
        
        if (len(bpy.context.selected_objects) >1 ):
            self.report({'ERROR'}, "Error: more than one object is selected. Please select the Armature object.")
            return{ 'CANCELLED'}
        
        if bpy.context.object.type != 'ARMATURE':
            self.report({'ERROR'}, "Error: %s is not an Armature." % bpy.context.object.name)
            return{ 'CANCELLED'}

        bpy.ops.object.mode_set(mode="OBJECT")
        
        if bpy.context.object.type == 'ARMATURE':
            self.report({'INFO'}, "Forward & lateral movement are removed")
            
        #get frame range of the animation
        first_frame = bpy.context.selected_objects[0].animation_data.action.frame_range[0]
        first_frame = int(first_frame)
        frame_range = bpy.context.selected_objects[0].animation_data.action.frame_range[1]
        frame_range = int(frame_range)
        frame_range +=1

        if ((bpy.context.selected_objects[0].name) == "root"):

            for i in range(first_frame, frame_range):

                for j in range(first_frame, frame_range):
                    bpy.context.selected_objects[0].location[0] = 0
                    bpy.context.selected_objects[0].keyframe_insert(data_path="location", frame=j, index=0)
                    bpy.context.selected_objects[0].location[0] = 0
                    
                
                #set current frame
                bpy.context.scene.frame_current = i
                
                #set Z location 0 for every keyframe
                
                bpy.context.selected_objects[0].location[1] = 0
                bpy.context.selected_objects[0].keyframe_insert(data_path="location", frame=i, index=1)
                bpy.context.selected_objects[0].location[1] = 0
                
                #insert keyframe to make it permenant
                bpy.ops.anim.keyframe_insert_menu(type='Location')
                
                
            #go back to the first frame    
            bpy.context.scene.frame_current = first_frame
            
            return {'FINISHED'}
        
        else:
            try:
                for i in range(first_frame, frame_range):

                    for j in range(first_frame, frame_range):
                        bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].location[0] = 0
                        bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].keyframe_insert(data_path="location", frame=j, index=0)
                        bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].location[0] = 0

                    
                    #set current frame
                    bpy.context.scene.frame_current = i
                    
                    #set Z location 0 for every keyframe
                    
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].location[2] = 0
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].keyframe_insert(data_path="location", frame=i, index=2)
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].location[2] = 0
                    
                    #insert keyframe to make it permenant
                    bpy.ops.anim.keyframe_insert_menu(type='Location')
                    
                    
                #go back to the first frame    
                bpy.context.scene.frame_current = first_frame
                
                return {'FINISHED'}
            except:
                for i in range(first_frame, frame_range):

                    for j in range(first_frame, frame_range):
                        bpy.context.selected_objects[0].pose.bones["Hips"].location[0] = 0
                        bpy.context.selected_objects[0].pose.bones["Hips"].keyframe_insert(data_path="location", frame=j, index=0)
                        bpy.context.selected_objects[0].pose.bones["Hips"].location[0] = 0

                    
                    #set current frame
                    bpy.context.scene.frame_current = i
                    
                    #set Z location 0 for every keyframe
                    
                    bpy.context.selected_objects[0].pose.bones["Hips"].location[2] = 0
                    bpy.context.selected_objects[0].pose.bones["Hips"].keyframe_insert(data_path="location", frame=i, index=2)
                    bpy.context.selected_objects[0].pose.bones["Hips"].location[2] = 0
                    
                    #insert keyframe to make it permenant
                    bpy.ops.anim.keyframe_insert_menu(type='Location')
                    
                    
                #go back to the first frame    
                bpy.context.scene.frame_current = first_frame
                
                return {'FINISHED'}
    
class MixamoInPlacerLateral(bpy.types.Operator):
    """Remove lateral movement only"""
    bl_idname = "object.mixamo_in_placer_lateral"
    bl_label = "Lateral Movement"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        
        
        # Check selected object(s)
        
        if (len(bpy.context.selected_objects) <1 ):
            self.report({'ERROR'}, "Error: no object is selected. Please select the Armature object.")
            return{ 'CANCELLED'}
        
        if (len(bpy.context.selected_objects) >1 ):
            self.report({'ERROR'}, "Error: more than one object is selected. Please select the Armature object.")
            return{ 'CANCELLED'}
        
        if bpy.context.object.type != 'ARMATURE':
            self.report({'ERROR'}, "Error: %s is not an Armature." % bpy.context.object.name)
            return{ 'CANCELLED'}
        
        bpy.ops.object.mode_set(mode="OBJECT")
        
        if bpy.context.object.type == 'ARMATURE':
            self.report({'INFO'}, "Lateral movement is removed")
        
        
        # Get frame range of the animation
        first_frame = bpy.context.selected_objects[0].animation_data.action.frame_range[0]
        first_frame = int(first_frame)
        frame_range = bpy.context.selected_objects[0].animation_data.action.frame_range[1]
        frame_range = int(frame_range)
        frame_range +=1

        if ((bpy.context.selected_objects[0].name) == "root"):

            for i in range(first_frame, frame_range):
            
                # Set current frame
                bpy.context.scene.frame_current = i
                
                # Set X location 0 for every keyframe
                
                bpy.context.selected_objects[0].location[0] = 0
                bpy.context.selected_objects[0].keyframe_insert(data_path="location", frame=i, index=0)
                bpy.context.selected_objects[0].location[0] = 0  
                
                #insert keyframe to make it permenant
                bpy.ops.anim.keyframe_insert_menu(type='Location')
            
            #go back to the first frame    
            bpy.context.scene.frame_current = first_frame
            
            return {'FINISHED'}
        
        else:
            try:
            
                for i in range(first_frame, frame_range):
                    
                    #set current frame@
                    bpy.context.scene.frame_current = i
                    
                    #set X location 0 for every keyframe
                    
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].location[0] = 0
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].keyframe_insert(data_path="location", frame=i, index=0)
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].location[0] = 0
                    
                    #insert keyframe to make it permenant
                    bpy.ops.anim.keyframe_insert_menu(type='Location')
                
                
                #go back to the first frame    
                bpy.context.scene.frame_current = first_frame
            
                return {'FINISHED'}
            except:
                for i in range(first_frame, frame_range):
                    
                    #set current frame@
                    bpy.context.scene.frame_current = i
                    
                    #set X location 0 for every keyframe
                    
                    bpy.context.selected_objects[0].pose.bones["Hips"].location[0] = 0
                    bpy.context.selected_objects[0].pose.bones["Hips"].keyframe_insert(data_path="location", frame=i, index=0)
                    bpy.context.selected_objects[0].pose.bones["Hips"].location[0] = 0
                    
                    #insert keyframe to make it permenant
                    bpy.ops.anim.keyframe_insert_menu(type='Location')
                
                
                #go back to the first frame    
                bpy.context.scene.frame_current = first_frame
                return {'FINISHED'}
    
    
class MixamoInPlacerUpward(bpy.types.Operator):
    """Remove upward movement"""
    bl_idname = "object.mixamo_in_placer_upward"
    bl_label = "Upward Movement"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        
        # Check selected object(s)
        
        if (len(bpy.context.selected_objects) <1 ):
            self.report({'ERROR'}, "Error: no object is selected. Please select the Armature object.")
            return{ 'CANCELLED'}
        
        if (len(bpy.context.selected_objects) >1 ):
            self.report({'ERROR'}, "Error: more than one object is selected. Please select the Armature object.")
            return{ 'CANCELLED'}
        
        if bpy.context.object.type != 'ARMATURE':
            self.report({'ERROR'}, "Error: %s is not an Armature." % bpy.context.object.name)
            return{ 'CANCELLED'}
        
        bpy.ops.object.mode_set(mode="OBJECT")
        
        if bpy.context.object.type == 'ARMATURE':
            self.report({'INFO'}, "Upward movement is removed")
            
        
        # Get frame range of the animation
        first_frame = bpy.context.selected_objects[0].animation_data.action.frame_range[0]
        first_frame = int(first_frame)
        frame_range = bpy.context.selected_objects[0].animation_data.action.frame_range[1]
        frame_range = int(frame_range)
        frame_range +=1

        if ((bpy.context.selected_objects[0].name) == "root"):

            currentZ = bpy.context.selected_objects[0].location[2]

            for i in range(first_frame, frame_range):
                
                # Set current frame
                bpy.context.scene.frame_current = i
                
                # Set Z location 0 for every keyframe
                bpy.context.selected_objects[0].location[2] = currentZ
                bpy.context.selected_objects[0].keyframe_insert(data_path="location", frame=i, index=2)
                bpy.context.selected_objects[0].location[2] = currentZ
                
                
                # Insert keyframe to make it permenant
                bpy.ops.anim.keyframe_insert_menu(type='Location')
                
                
            # Go back to the first frame    
            bpy.context.scene.frame_current = first_frame
            
            return {'FINISHED'}
            
        else:
            try:
            
                for i in range(first_frame, frame_range):
                    
                    #set current frame@
                    bpy.context.scene.frame_current = i
                    
                    #set Y location 0 for every keyframe
                    
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].location[1] = 0
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].keyframe_insert(data_path="location", frame=i, index=1)
                    bpy.context.selected_objects[0].pose.bones["mixamorig:Hips"].location[1] = 0
                    
                    #insert keyframe to make it permenant
                    bpy.ops.anim.keyframe_insert_menu(type='Location')
                
                
                #go back to the first frame    
                bpy.context.scene.frame_current = first_frame
            
                return {'FINISHED'}
            except:
                for i in range(first_frame, frame_range):
                    
                    #set current frame@
                    bpy.context.scene.frame_current = i
                    
                    #set Y location 0 for every keyframe
                    
                    bpy.context.selected_objects[0].pose.bones["Hips"].location[1] = 0
                    bpy.context.selected_objects[0].pose.bones["Hips"].keyframe_insert(data_path="location", frame=i, index=1)
                    bpy.context.selected_objects[0].pose.bones["Hips"].location[1] = 0
                    
                    #insert keyframe to make it permenant
                    bpy.ops.anim.keyframe_insert_menu(type='Location')
                
                
                #go back to the first frame    
                bpy.context.scene.frame_current = first_frame
                return {'FINISHED'}
            

classes = [MixamoInPlacerForward, MixamoInPlacerForwardandLateral, MixamoInPlacerLateral, MixamoInPlacerUpward]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

