import bpy
import os
from . import In_Placer_Panels

script_file = os.path.realpath(__file__)
addon_directory = os.path.dirname(script_file)
addon_name = os.path.basename(addon_directory)


def update_panel(self, context):

    addon_preferences = context.preferences.addons[addon_name].preferences
    message = ": Updating Panel locations has failed"
    try:

        if "bl_rna" in In_Placer_Panels.INPLACER_PT_Side_Panel.__dict__:
            bpy.utils.unregister_class(In_Placer_Panels.INPLACER_PT_Side_Panel)
            

        In_Placer_Panels.INPLACER_PT_Side_Panel.bl_category = addon_preferences.side_panel_name
        bpy.utils.register_class(In_Placer_Panels.INPLACER_PT_Side_Panel)

    except Exception as e:
        print("\n[{}]\n{}\n\nError:\n{}".format(__name__, message, e))
        pass

    try:

        if "bl_rna" in In_Placer_Panels.INPLACER_PT_Side_Panel_SubPanel.__dict__:
            bpy.utils.unregister_class(In_Placer_Panels.INPLACER_PT_Side_Panel_SubPanel)
            

        In_Placer_Panels.INPLACER_PT_Side_Panel_SubPanel.bl_category = addon_preferences.side_panel_name
        bpy.utils.register_class(In_Placer_Panels.INPLACER_PT_Side_Panel_SubPanel)

    except Exception as e:
        print("\n[{}]\n{}\n\nError:\n{}".format(__name__, message, e))
        pass


class In_Placer_user_preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    side_panel: bpy.props.BoolProperty(default=True)

    side_panel_name: bpy.props.StringProperty(default="In Placer", update=update_panel)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "side_panel_name", text="Side Panel Catagory")

        layout.prop(self, "side_panel", text="Show in Side Panel")

classes = [In_Placer_user_preferences]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    update_panel(None, bpy.context)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
