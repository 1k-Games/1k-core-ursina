import bpy
import os


script_file = os.path.realpath(__file__)
addon_directory = os.path.dirname(script_file)
addon_name = os.path.basename(addon_directory)


class INPLACER_PT_Side_Panel(bpy.types.Panel):
    bl_idname = "INPLACER_PT_Side_Panel"
    bl_label = "In Placer"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "In Placer"
    bl_order = 0

    @classmethod
    def poll(cls, context):

        addon_preferences = context.preferences.addons[addon_name].preferences

        if addon_preferences.side_panel:
            return True
        else:
            return False

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row = layout.row()
        row.scale_y = 1.5
        row.operator("object.mixamo_in_placer_forward_and_lateral", icon='ARMATURE_DATA')

class INPLACER_PT_Side_Panel_SubPanel(bpy.types.Panel):

    bl_label = "One Direction Only"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "In Placer"
    bl_order = 1
    bl_options = {'DEFAULT_CLOSED'}


    @classmethod
    def poll(cls, context):

        addon_preferences = context.preferences.addons[addon_name].preferences

        if addon_preferences.side_panel:
            return True
        else:
            return False

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row = layout.row()
        row.scale_y = 1.5
        row.operator("object.mixamo_in_placer_forward")
        row = layout.row()
        row = layout.row()
        row.scale_y = 1.5
        row.operator("object.mixamo_in_placer_lateral")
        row = layout.row()
        row = layout.row()
        row.scale_y = 1.5
        row.operator("object.mixamo_in_placer_upward")
        row = layout.row()
        
class PROPERTIES_PT_Panel:
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = 'data'
    bl_options = {"DEFAULT_CLOSED"}

class PROPERTIES_PT_Panel_1(PROPERTIES_PT_Panel, bpy.types.Panel):
    bl_idname = "PROPERTIES_PT_panel_1"
    bl_label = "In Placer"

    def draw(self, context):
        layout = self.layout        
        
        row = layout.row()
        row = layout.row()
        row.scale_y = 1.5
        row.operator("object.mixamo_in_placer_forward_and_lateral", icon='ARMATURE_DATA')

class PROPERTIES_PT_Panel_2(PROPERTIES_PT_Panel, bpy.types.Panel):
    bl_parent_id = "PROPERTIES_PT_panel_1"
    bl_label = "One Direction Only"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row = layout.row()
        row.scale_y = 1.5
        row.operator("object.mixamo_in_placer_forward")
        row = layout.row()
        row.scale_y = 1.5
        row.operator("object.mixamo_in_placer_lateral")
        row = layout.row()
        row.scale_y = 1.5
        row.operator("object.mixamo_in_placer_upward")
        row = layout.row()

classes = (INPLACER_PT_Side_Panel, INPLACER_PT_Side_Panel_SubPanel,PROPERTIES_PT_Panel_1, PROPERTIES_PT_Panel_2,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()