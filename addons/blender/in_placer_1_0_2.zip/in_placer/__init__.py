bl_info = {
    "name": "in placer",
    "author": "Fatih Pehlevan",
    "version": (1, 0, 2),
    "blender": (2, 80, 0),
    "description": "Making an animation in place without using the graph editor.",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}

import bpy
from . import In_Placer_Operators
from . import In_Placer_Panels
from . import Preferences

modules = [In_Placer_Operators, In_Placer_Panels, Preferences]

def register():
    for module in modules:
        module.register()

def unregister():
    for module in modules:
        module.unregister()

if __name__ == "__main__":
    register()
